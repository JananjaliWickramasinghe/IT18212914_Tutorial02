package jananjali.intentsproj;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    public Button plusbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        EditText v1 = (EditText)findViewById(R.id.no1);
        EditText v2 = (EditText) findViewById(R.id.no2);
        int val1 = Integer.valueOf(v1.getText().toString());
        int val2 = Integer.valueOf(v2.getText().toString());


        Bundle bundle = getIntent().getExtras();
        int Num1=  bundle.getInt("NumberOne");
        int Num2 =  bundle.getInt("NumberTwo");



        TextView num1 = (TextView) findViewById(R.id.numlabel1);
        TextView symb = (TextView) findViewById(R.id.textView9);
        TextView num2 = (TextView) findViewById(R.id.numlabel2);
        TextView answer = (TextView) findViewById(R.id.answer);

        num1.setText(Num1);
        symb.setText("+");
        num2.setText(Num2);
        answer.setText(val1+val2);




    }


    public void CalSum(){

        EditText v1 = (EditText)findViewById(R.id.no1);
        EditText v2 = (EditText) findViewById(R.id.no2);


        int val1 = Integer.valueOf(v1.getText().toString());
        int val2 = Integer.valueOf(v2.getText().toString());


        TextView num1 = (TextView) findViewById(R.id.numlabel1);
        TextView symb = (TextView) findViewById(R.id.textView9);
        TextView num2 = (TextView) findViewById(R.id.numlabel2);
        TextView answer = (TextView) findViewById(R.id.answer);

        num1.setText(val1);
        symb.setText("+");
        num2.setText(val2);
        answer.setText(val1+val2);

    }


    public void CalMulti(){

        EditText v1 = (EditText)findViewById(R.id.no1);
        EditText v2 = (EditText) findViewById(R.id.no2);


        int val1 = Integer.valueOf(v1.getText().toString());
        int val2 = Integer.valueOf(v2.getText().toString());


        TextView num1 = (TextView) findViewById(R.id.numlabel1);
        TextView symb = (TextView) findViewById(R.id.textView9);
        TextView num2 = (TextView) findViewById(R.id.numlabel2);
        TextView answer = (TextView) findViewById(R.id.answer);

        num1.setText(val1);
        symb.setText("*");
        num2.setText(val2);
        answer.setText(val1*val2);

    }

    public void CalDiv(){

        EditText v1 = (EditText)findViewById(R.id.no1);
        EditText v2 = (EditText) findViewById(R.id.no2);


        int val1 = Integer.valueOf(v1.getText().toString());
        int val2 = Integer.valueOf(v2.getText().toString());


        TextView num1 = (TextView) findViewById(R.id.numlabel1);
        TextView symb = (TextView) findViewById(R.id.textView9);
        TextView num2 = (TextView) findViewById(R.id.numlabel2);
        TextView answer = (TextView) findViewById(R.id.answer);

        num1.setText(val1);
        symb.setText("/");
        num2.setText(val2);
        answer.setText(val1/val2);

    }


    public void Calsub(){

        EditText v1 = (EditText)findViewById(R.id.no1);
        EditText v2 = (EditText) findViewById(R.id.no2);


        int val1 = Integer.valueOf(v1.getText().toString());
        int val2 = Integer.valueOf(v2.getText().toString());


        TextView num1 = (TextView) findViewById(R.id.numlabel1);
        TextView symb = (TextView) findViewById(R.id.textView9);
        TextView num2 = (TextView) findViewById(R.id.numlabel2);
        TextView answer = (TextView) findViewById(R.id.answer);

        num1.setText(val1);
        symb.setText("-");
        num2.setText(val2);
        answer.setText(val1-val2);

    }



}
