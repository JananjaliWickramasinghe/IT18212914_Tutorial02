package jananjali.intentsproj;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class FirstActivity extends AppCompatActivity {

    private Button button;

    EditText edittext1;
    EditText edittext2;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        edittext1 =(EditText) findViewById(R.id.Number1_page1);
        edittext2 =(EditText) findViewById(R.id.Number2_page1);


        button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Context context = getApplicationContext();
                CharSequence message = "Next Page loading..";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, message, duration);
                //toast.setGravity(50, 50, 50);
                toast.show();

                int number1 = Integer.parseInt(edittext1.getText().toString());
                int number2 = Integer.parseInt(edittext2.getText().toString());

                Intent intent = new Intent(FirstActivity.this, SecondActivity.class);
                intent.putExtra("NumberOne",number1);
                intent.putExtra("NumberTwo",number2);

                startActivity(intent);
            }


        });
    }




}
